import java.util.ArrayList;

//House is the ArrayList of rooms (nodes)
public class House<T>{
	private ArrayList<Room<T>> rooms;
	private int size;
	//Initializes the House
	public House(){
		rooms = new ArrayList<Room<T>>();
		size = 0;
	}
	//Allows us to add a Room to the House
	public void add(T data){
		rooms.add(new Room<T>(data));
		size ++;
	}
	//Allows us to add a connection to a Room in the House
	public void addConnection(int s, int e){
		rooms.get(s).add(rooms.get(e));
	}
	//Allows us to get a Room from the House
	public Room<T> get(int n){
		return rooms.get(n);
	}
}