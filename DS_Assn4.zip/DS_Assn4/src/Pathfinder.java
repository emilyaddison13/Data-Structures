import java.util.*;
import java.io.*;

//Pathfinder is the main class, where we create a House filled with Rooms,
//and determine the shortest path from one Room in the House to another Room
public class Pathfinder{
	public static void main(String[]args) throws IOException{
		
		//Initializing the Room nodes and House graph from the given input file
			House<Integer> house = new House<Integer>();
	
			//Reads from test file
			Scanner input = new Scanner(new BufferedReader(new FileReader("test.txt")));
			input.nextLine();	//Needed if input file has a header, otherwise comment out
			
			//Takes the first three values and stores them as string values for size, start point, and end point
			String tempSize = input.nextLine(),
					tempStart = input.nextLine(),
					tempEnd = input.nextLine();
			//Changes the string values for size, start point, and end point to int values
			int size = Integer.parseInt(tempSize),
					start = Integer.parseInt(tempStart),
					end = Integer.parseInt(tempEnd);
			
			//Adds rooms equal to the number of rooms declared in the input file (size)
			for(int i=0;i<size;i++) 
				house.add(i);
			
			//Reads the array of room connections from the input file and creates a House accordingly
			//Iterates through the number of lines(i), and number of entries per line(j)
			for(int i=0;i<size;i++){
				String temp = input.nextLine();
				String[] connections = temp.split(",");
				for(int j=0;j<size;j++){
					if(connections[j].equals("1")){
						house.addConnection(i,j);	//Adds a connection if the value is 1
					}
				}
			}
		//End of initialization
		
		//Using the given House graph, search for the shortest path from one room to another
			Queue<Room<Integer>> path = new Queue<Room<Integer>>();
			boolean[] visited = new boolean[size];
			int[] prev = new int[size];
			
			//Initializes the previous Rooms to -1
			for(int i=0;i<size;i++) 
				prev[i] = -1;
			
			//Begins the path at the given starting Room
			path.enqueue(house.get(start));
			
			//Traverse the House 
			while(path.size() > 0){
				Room<Integer> currentRoom = path.dequeue();
				//If not visited yet, then mark as visited
				if(visited[currentRoom.getInfo()] == false){
					visited[currentRoom.getInfo()] = true;
					//For each Room connected to the current Room
					for(Room<Integer> connectedRoom : currentRoom.getConnection()){
						//If not visited, then add to path being checked, otherwise skip the Room already visited
						if(visited[connectedRoom.getInfo()] == false){
							path.enqueue(connectedRoom);
							//If we check a new Room (next Room), then its previous Room is set to the current Room
							if(prev[connectedRoom.getInfo()] == -1) 
								prev[connectedRoom.getInfo()] = currentRoom.getInfo();
						}
					}
				}
			}
		//End of searching
			
		//Printing the results of the path-finding
			ArrayList<Integer> shortest = new ArrayList<Integer>();
			//If traversing from one Room to the same Room, the path is the Room
			if(start == end) 
				System.out.println(start);
			//If the two Rooms do not have a possible path, indicate no possible path
			else if(prev[end] == -1) 
				System.out.println("No possible path");
			//If a path exists between two different Rooms, 
			else{
				int currentRoom = end;
				shortest.add(end);	//Start at the ending Room 
				//While a previous Room exists (not starting Room)
				while(prev[currentRoom] != -1){
					shortest.add(prev[currentRoom]);
					currentRoom = prev[currentRoom];
				}
				System.out.println("The shortest path is from Room " + tempStart + " to Room " + tempEnd + " is:");
				//Loop through the ArrayList in reverse order since path was added from ending Room to starting Room
				for(int i=shortest.size()-1; i>=1; i--)
					System.out.print(shortest.get(i) + ",");
				System.out.println(shortest.get(0));
			}
		//End of Printing
			
		input.close();
	}
}
