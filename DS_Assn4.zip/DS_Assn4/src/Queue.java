import java.util.*;

//The queue used in the path-finding algorithm
public class Queue<T>{
	private ArrayList<T> path;
	private T start;
	@SuppressWarnings("unused")
	private T end;
	//Constructor to initialize the queue
	public Queue(){
		path = new ArrayList<T>();
		start = null;
		end = null;
	}
	//Enqueue method to add a room to the path
	public void enqueue(T Room){
		path.add(Room);
		if(path.size() == 1){
			start = path.get(0);
			end = path.get(0);
		}
		else
			end = path.get(path.size() - 1);
	}
	//Dequeue method to remove path already checked
	public T dequeue(){
		if(path.size() == 0) 
			return null;
		T Room = start;
		path.remove(0);
		if(path.size() == 0){
			start = null;
			end = null;
		}
		else
			start = path.get(0);
		return Room;
	}
	//Size method to check the length of the path
	public int size(){
		return path.size();
	}
}