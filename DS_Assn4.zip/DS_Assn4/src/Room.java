import java.util.ArrayList;

//Room is a node used in the ArrayList, representing a single Room in the House
public class Room<T>{
	private ArrayList<Room<T>> connection;
	private T info;
	//Initializes the Room
	public Room(T i){
		connection = new ArrayList<Room<T>>();
		info = i;
	}
	//Allows the adding of Rooms
	public void add(Room<T> n){
		connection.add(n);
	}
	//Allows us to get the number stored in a Room
	public T getInfo(){
		return info;
	}
	//Allows us to get the connections to a Room
	public ArrayList<Room<T>> getConnection(){
		return connection;
	}
}